import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { NgxSpinnerService } from "ngx-spinner";

const BASE_URL = 'https://api.weatherbit.io/v2.0/forecast/daily?';
const KEY = '&key=371d4e84f04f4e6eafe38174f3de11e5';
const NUM_DAYS = 5;

@Injectable({
  providedIn: 'root'
})
export class WeatherCallService {

  constructor(private http: HttpClient, private SpinnerService: NgxSpinnerService) { }
  /**
   * Method to generate URL
   * @param qParams 
   * @returns 
   */
  getUrl(qParams: string) {
    return (BASE_URL + qParams + KEY);
  }
  /**
   * Method to call http request
   * @param qParams 
   * @returns 
   */
  getWeatherData(qParams: any): Observable<any> {
    let subUrl = `city=${qParams.city},${qParams.countryCode}&days=${NUM_DAYS}`;
    let urlStr = this.getUrl(subUrl);

    return this.http.get(urlStr).pipe(
      catchError((err) => {
        console.error(err);
        alert('Oh! Error occured');
        return throwError(err);    //Rethrow error it back to component
      })
    );
  }
  /**
   * Method to handle error
   * @param error 
   */
  handleError(error: any) {
    if (error instanceof HttpErrorResponse) {
      if (error.error instanceof ErrorEvent) {
        console.error("Error Event");
      } else {
        console.log(`error status : `, error);
      }
    }
    else {
      console.error("Other Errors");
    }
  }
  /**
   * Method to show spinner
   */
  showSpinner() {
    this.SpinnerService.show();
  }
  /**
 * Method to hide spinner
 */
  hideSpinner() {
    this.SpinnerService.hide();
  }
}
