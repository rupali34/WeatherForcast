import { Component } from '@angular/core';
import { WeatherCallService } from './services/weather-call.service';
import { DatePipe } from '@angular/common'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'WeatherForecast';
  cityList = [{
    city_name: 'Pune',
    country_code: 'IN'
  },
  {
    city_name: 'London',
    country_code: 'GB'
  },
  {
    city_name: 'Mumbai',
    country_code: 'IN'
  },
  {
    city_name: 'Raleigh',
    country_code: 'US'
  },
  {
    city_name: 'Delhi',
    country_code: 'IN'
  }];
  selectedCity = this.cityList[0];
  weath_subscriber: any;
  weatherData = [];

  constructor(private weatherCallService: WeatherCallService) { }
  /**
   * Life cycle hook method
   */
  ngOnInit() {
    this.fetchData();
  }
  /**
 * Method to set selected citi and fetch data on selection
 */
  onSelectCity(selcity: any) {
    console.log(selcity);
    this.selectedCity = selcity;
    this.fetchData();
  }
  /**
   * Method to fetch 5 days weather data
   */
  fetchData() {
    let qParams = {
      city: this.selectedCity.city_name,
      countryCode: this.selectedCity.country_code
    };
    this.weatherCallService.showSpinner();
    this.weath_subscriber = this.weatherCallService.getWeatherData(qParams).subscribe((result: any) => {
      if (result && (result.data && result.data.length > 0)) {
        this.weatherData = result.data;
      }
      this.weatherCallService.hideSpinner();
    }, (error: any) => {
      console.log('Oh! Error occured');
      alert('Oh! Error occured');
      this.weatherCallService.hideSpinner();
    });
  }
  /**
  * Life cycle hook method
  */
  ngOnDestroy() {
    this.weath_subscriber.unsubscribe();
  }

}
